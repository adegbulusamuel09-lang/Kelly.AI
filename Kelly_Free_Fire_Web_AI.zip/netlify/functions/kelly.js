exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return { statusCode: 405, body: "Method not allowed" };
  if (!process.env.OPENAI_API_KEY) return { statusCode: 500, body: JSON.stringify({ error: "Site owner: set OPENAI_API_KEY in Netlify environment variables." }) };
  try {
    const { question } = JSON.parse(event.body || "{}");
    if (!question || typeof question !== "string" || question.length > 4000) return { statusCode: 400, body: JSON.stringify({ error: "Please enter a question (maximum 4000 characters)." }) };
    const prompt = `You are Kelly, a helpful Free Fire information assistant on a fan website. Be friendly, clear, and concise. Prioritize official Free Fire/Garena sources for announcements, patch notes, events, and redeem-code claims. Search the web for current questions, latest updates, rankings, current codes, dates, or other time-sensitive claims. Never invent live leaderboard data, redeem codes, events, patch details, or citations. If reliable current data isn't available, say so plainly. For strategy and general knowledge, web search when useful. Keep answers suitable for a teen audience. Question: ${question}`;
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model: process.env.KELLY_MODEL || "gpt-6.2-astra", tools: [{ type: "web_search" }], input: prompt })
    });
    const payload = await response.json();
    if (!response.ok) return { statusCode: response.status, body: JSON.stringify({ error: payload.error?.message || "AI API request failed." }) };
    const answer = payload.output_text || "I couldn't generate an answer.";
    const sources = [];
    for (const item of (payload.output || [])) {
      for (const content of (item.content || [])) {
        for (const annotation of (content.annotations || [])) {
          if (annotation.type === "url_citation" && annotation.url_citation?.url) {
            const c = annotation.url_citation;
            if (!sources.some(s => s.url === c.url)) sources.push({ url: c.url, title: c.title || c.url });
          }
        }
      }
    }
    return { statusCode: 200, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ answer, sources }) };
  } catch (error) {
    return { statusCode: 500, body: JSON.stringify({ error: "Kelly had a connection error. Try again." }) };
  }
};