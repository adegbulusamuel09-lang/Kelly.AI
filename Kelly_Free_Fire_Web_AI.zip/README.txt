KELLY - FREE FIRE WEB AI STARTER

Files: index.html, style.css, app.js, netlify/functions/kelly.js, netlify.toml

DEPLOY:
1. Extract this ZIP.
2. Netlify -> Add new site / Deploy manually. Upload the extracted project folder (or ZIP if the interface supports ZIP deploy).
3. For the serverless function and API, use Netlify's Git-connected deployment (recommended): create a GitHub repository, upload all files, then import that repo in Netlify. The functions folder must be included.
4. In Netlify Site configuration -> Environment variables, add:
   OPENAI_API_KEY = your API key
   Optional: KELLY_MODEL = a model available to your API account
5. Trigger a redeploy after setting environment variables.
6. Test Kelly from the floating button. Answers render in the on-site chat, and source links appear below answers when provided.

IMPORTANT:
- Netlify hosting may have a free tier, but AI API usage/web search can incur charges. An API key is not included.
- Never put the API key in app.js or HTML. Keep it as a Netlify environment variable.
- Model default is gpt-6.2-astra in this starter; if your API account doesn't support it, set KELLY_MODEL to a supported model that has web-search tool access.
- Current leaderboard information may not be available from official/public sources; Kelly is instructed not to invent it.
- This is a starter, not an official Garena product.
